package DefiningClassesLab.CarInfo;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numberCars = Integer.parseInt(scanner.nextLine());

        while (numberCars-- > 0){
            String[] data = scanner.nextLine().split("\\s+");
            int horsePower = Integer.parseInt(data[2]);

            Car car = new Car();
            car.setMake(data[0]);
            car.setModel(data[1]);
            car.setHorsePower(horsePower);

            System.out.println(car.toString());
        }
    }
}
